/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_usleep.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 00:08:59 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/24 12:13:55 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

long	ft_usleep(long time)
{
	long	start;

	start = current_time_ms();
	while (current_time_ms() - start < time)
		usleep(100);
	return (0);
}
