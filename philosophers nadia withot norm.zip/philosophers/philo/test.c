
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>


int main ()
{
  int i;
  int x;

    i = 0;
    x = 5;
    while (i < x)
    {

        if ((i + 1 )== 5)
        {
            printf("this is !!!\n");
            return 0;
        }
            printf("i = %d\n", i);
        i++;
    }

}

