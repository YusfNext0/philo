/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_simulation.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/26 21:09:52 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/27 14:12:24 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void display_simulation(t_philo *philo, char *str)
{
	long	all_done;

	pthread_mutex_lock(&philo->data->data_access);
	all_done = philo->data->all_done;
	pthread_mutex_unlock(&philo->data->data_access);
	if (all_done != 0)
	{
		return ;
	}
	pthread_mutex_lock(&philo->data->write_acess);
	printf("%ld %ld %s\n", (current_time_ms() - philo->data->start_time), philo->id, str);
	pthread_mutex_unlock(&philo->data->write_acess);
}