/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sim_philo.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/14 23:34:48 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/27 14:39:24 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

// void display_simulation(t_philo *philo, char *str)
// {
// 	pthread_mutex_lock(&philo->data->write_acess);
// 	printf("%ld %ld %s\n", (current_time_ms() - philo->data->start_time), philo->id, str);
// 	pthread_mutex_unlock(&philo->data->write_acess);
// }

void	eating(t_philo *philo)
{
	// if (philo->data->nb_ph == 1)
	// {
	// 	philo->data->all_done = 1;
	// 	// printf("testedcjkdnsck;dn\n");
	// 	// return ;
	// }
	pthread_mutex_lock(&philo->data->data_access);
	if (philo->data->all_done != 0)
	{
		pthread_mutex_unlock(&philo->data->data_access);
		return ;
	}
	pthread_mutex_unlock(&philo->data->data_access);
	pthread_mutex_lock(philo->left_fork);
	display_simulation(philo, "has taken a fork");
	if (philo->data->nb_ph == 1)
	{
	// ft_usleep(100);
		philo->data->all_done = 1;
		// printf("testedcjkdnsck;dn\n");
		return ;
	}
	pthread_mutex_lock(philo->right_fork);
	display_simulation(philo, "has taken a fork");	
	display_simulation(philo, "is eating");
	ft_usleep(philo->data->time_to_eat);
	pthread_mutex_lock(&philo->philo_access);
	philo->last_meal = current_time_ms();
	pthread_mutex_unlock(&philo->philo_access);
	pthread_mutex_unlock(philo->left_fork);
	pthread_mutex_unlock(philo->right_fork);
}

void	sleeping(t_philo *philo)
{
	pthread_mutex_lock(&philo->data->data_access);
	if (philo->data->all_done != 0)
	{
		pthread_mutex_unlock(&philo->data->data_access);
		return ;
	}
	pthread_mutex_unlock(&philo->data->data_access);
	display_simulation(philo, "is sleeping");
	ft_usleep(philo->data->time_to_sleep);
}

void	*routine(void *param)
{
	t_philo *philo;
	long	nb_m;

	philo = (t_philo *)param;
	if (philo->id % 2 == 0)
		ft_usleep(philo->data->time_to_eat);
	while (1)
	{
		eating(philo);
		sleeping(philo);
		pthread_mutex_lock(&philo->data->data_access);
		if (philo->data->all_done != 0)
		{
			pthread_mutex_unlock(&philo->data->data_access);
			break ;
		}
		pthread_mutex_unlock(&philo->data->data_access);
		display_simulation(philo, "is thinking");
		philo->nbr_meal += 1;
		pthread_mutex_lock(&philo->philo_access);
		nb_m = philo->nbr_meal;
		pthread_mutex_unlock(&philo->philo_access);
		if (nb_m == philo->data->nb_time_eat)	
			break ;
	}
	return (NULL);
}

void	sim_philo(t_data *data)
{
	int i;

	i = 0;
	while (i < data->nb_ph)
	{
		if (pthread_create(&data->philo[i].th_philo , NULL, routine , &data->philo[i]))
		{
			printf("Error thread id %ld\n", data->philo[i].id);
			return ;
		}
		i++;
	}
	monitoring(data);
	i = 0;
	while (i < data->nb_ph)
	{
		pthread_join(data->philo[i].th_philo, NULL);
		i++;
	}
	pthread_join(data->main_thread, NULL);
	destroy_all(data);
}
