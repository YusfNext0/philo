/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitoring.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 20:54:45 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/24 22:01:41 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void *monitor(void *param)
{
	t_philo *philo;
	int	i;

	philo = (t_philo *)param;
	i = 0;
	// while (i < philo->data->nb_ph)
	// {
	// 	if ((current_time_ms() - philo[i].data->start_time) >= philo[i].data->time_to_die && (philo[i].data->nb_time_eat == -1))
	// 	{
	// 		printf("%ld %ld died\n",(current_time_ms() - philo[i].data->start_time), philo[i].id);
	// 		exit(1);
	// 	}
	// 	i = (i + 1) % philo[i].data->nb_ph;
	// 	sleep(1);
	// 	if (philo[i].data->nb_time_eat == 0)
	// 		break ;
	// }

	while (i < philo->data->nb_ph)
	{
		if ((current_time_ms() - philo[i].last_meal) >= philo[i].data->time_to_die && (philo[i].data->nb_time_eat == -1))
		{	
			printf("%ld %ld died\n",(current_time_ms() - philo[i].last_meal), philo[i].id);
			exit(1);
		}
		i = (i + 1) % philo[i].data->nb_ph;
		// if (philo->data->all_nb_meal == philo->data->nb_ph)
		// 	exit(1);
	}
	return (NULL);
}

void monitoring(t_data *data)
{
	if (pthread_create(&data->main_thread, NULL, monitor, data->philo))
	{
		printf("heeeeeeere is pthred_creat failed monitor <--\n");
		exit(1);
	}
}
