/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_information.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/08 12:31:23 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/16 09:52:47 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"
		// // to do 
		// //////////////////////
		// // manage eating () //
		// /////////////////////
		
		// 	// take left fork
		// pthread_mutex_lock(philo->left_fork);
		// 	// take right fork
		// pthread_mutex_lock(philo->right_fork);
		// 	// X is eating
		// printf("%d is eating\n", philo->id);
		// 	// start eating (usleep(time to eat))
		// usleep(philo->time_to_eat);
		// 	// put left fork
		// // if (philo->id == 2)
		// // {	printf("-->...%d\n",philo->id);
		// // 	exit(1);
		// // }
		// pthread_mutex_unlock(philo->left_fork);
		// 	// put right fork
		// pthread_mutex_unlock(philo->right_fork);
		// /////////////////////
		// // manage sleeping //
		// /////////////////////
		// 	//  X is sleeping
		// printf("%d is sleeping\n", philo->id);
		// 	// start sleeping
		// usleep(philo->time_to_sleep);
		// /////////////////////
		// // manage thinking //
		// /////////////////////
		// 	// X is thinking
		// printf("%d is thinking\n", philo->id);

void init_forks(t_data *data)
{
	int i;

	i = 0;
	// addtional forks
	data->forks = malloc(sizeof(pthread_mutex_t) * data->nb_ph);
	while (i < data->nb_ph)
	{
		pthread_mutex_init(&data->forks[i], NULL);
		i++;
	}
}

void init_inf_philos(t_data *data)
{
	int	i;

	i = 0;
	data->philo = malloc(sizeof(t_philo) * data->nb_ph);
	if (!data->philo)
	{
		printf("Error malloc philo\n");
		return ;
	}
	data->start_time = current_time_ms();
	i = 0;
	while (i < data->nb_ph)
	{	
		if (data->nb_time_eat > 0)
			data->philo[i].nbr_meal = data->nb_time_eat;
		data->philo[i].id = i + 1;
		data->philo[i].data = data;
		data->philo[i].left_fork = &data->forks[i];
		data->philo[i].right_fork = &data->forks[(i + 1) % data->nb_ph];
		i++;
	}
}

int init_information(t_data *data, int nb_philo, char **av)
{
	// shared data
	data->nb_ph = nb_philo;
	data->time_to_die = ft_atoi(av[2]);
	data->time_to_eat = ft_atoi(av[3]);
	data->time_to_sleep = ft_atoi(av[4]);
	if (ft_atoi(av[5]))
		data->nb_time_eat = ft_atoi(av[5]);
	else
		data->nb_time_eat = -1;
	// init forks
	init_forks(data);
	// init philos
	init_inf_philos(data);

	sim_philo(data);

	return (0);
}