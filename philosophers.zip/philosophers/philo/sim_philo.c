/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sim_philo.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/14 23:34:48 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/16 13:13:37 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void display_simulation(t_philo *philo, char *str, long curr_time, long id)
{
	(void) philo;
	printf("%ld %ld %s\n", curr_time, id, str);
}

void	eating(t_philo *philo)
{
	pthread_mutex_lock(philo->left_fork);
	display_simulation(philo, "has taken a fork", (current_time_ms() - philo->data->start_time), philo->id);
	pthread_mutex_lock(philo->right_fork);
	display_simulation(philo, "has taken a fork", (current_time_ms() - philo->data->start_time), philo->id);
	display_simulation(philo, "is eating", (current_time_ms() - philo->data->start_time), philo->id);
	ft_usleep(philo->data->time_to_eat);
	philo->last_meal = current_time_ms();
	pthread_mutex_unlock(philo->left_fork);
	pthread_mutex_unlock(philo->right_fork);
}

void	sleeping(t_philo *philo)
{
	display_simulation(philo, "is sleeping", (current_time_ms() - philo->data->start_time), philo->id);
	ft_usleep(philo->data->time_to_sleep);
}

void	*routine(void *param)
{
	t_philo *philo;

	philo = (t_philo *)param;
	if (philo->id % 2 == 0)
		ft_usleep(philo->data->time_to_eat);
	while (1)
	{
		eating(philo);
		sleeping(philo);
		display_simulation(philo, "is thinking", (current_time_ms() - philo->data->start_time), philo->id);
		if (philo->nbr_meal > 0)
			philo->nbr_meal--;
		if (philo->nbr_meal == 0)
			philo->data->nb_time_eat = 0 ;
	}
	return NULL;
}

void	sim_philo(t_data *data)
{
	int i;

	i = 0;
	while (i < data->nb_ph)
	{
		if (pthread_create(&data->philo[i].th_philo , NULL, routine , &data->philo[i]))
		{
			printf("Error thread id %ld\n", data->philo[i].id);
			return ;
		}
		i++;
	}
	monitoring(data);
	i = 0;
	while (i < data->nb_ph)
	{
		pthread_join(data->philo[i].th_philo, NULL);
		i++;
	}
	pthread_join(data->main_thread, NULL);
}
