/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/19 20:57:31 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/16 12:49:57 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int main(int ac, char *av[])
{
	t_data data;
	int		i;

	i = 0;
	if (ac == 5 || ac == 6)
	{
		if (parcing(ac, av) == -1)
		{
			printf("Erorr !!!\n");
			return (1);
		}
		init_information(&data, ft_atoi(av[1]), av);
		if (data.nb_time_eat == 0)
			exit(1);
	}else
	{
		printf("Error\n");
		return (1);
	}

	// simulate function
	// while (i < data->nb_ph)
	// {
	// 	if (pthread_create(data->philo[i].th_philo , NULL, routine , &data->philo[i]))
	// 	{
	// 		printf("Error thread id %d\n", data->philo[i].id);
	// 		return ;
	// 	}
	// 	i++;
	// }
	// i = 0;
	// while (i < data->nb_ph)
	// {
	// 	pthread_detach(data->philo[i].th_philo);
	// 	i++;
	// }
	// while (1)
	// 	;

	//monitoring
	// while (i < data.nb_ph)
	// {
	// 	if ((current_time_ms() - data.philo[i].data->start_time) >= data.time_to_die && (data.nb_time_eat == -1))
	// 	{
	// 		printf("%ld %ld died\n",(current_time_ms() - data.philo[i].data->start_time), data.philo[i].id);
	// 		return (1);
	// 	}
	// 	i = (i + 1) % data.nb_ph;
	// 	if (data.nb_time_eat == 0)
	// 		return (0);
	// }

	return (0);
}
