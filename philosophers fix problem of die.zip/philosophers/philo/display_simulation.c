/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_simulation.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/26 21:09:52 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/26 22:51:13 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void display_simulation(t_philo *philo, char *str)
{
	if (philo->data->all_done != 0)
	{
		return ;
	}
	pthread_mutex_lock(&philo->data->write_acess);
	printf("%ld %ld %s\n", (current_time_ms() - philo->data->start_time), philo->id, str);
	pthread_mutex_unlock(&philo->data->write_acess);
}