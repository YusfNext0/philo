/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/19 20:57:31 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/31 16:06:21 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	main(int ac, char *av[])
{
	t_data	data;
	int		i;

	i = 0;
	if (ac == 5 || ac == 6)
	{
		if (parcing(ac, av) == -1)
		{
			write(2, "Error\n", 7);
			return (1);
		}
		init_information(&data, ft_atoi(av[1]), av);
	}
	else
	{
		write(2, "Error\n", 7);
		return (1);
	}
	return (0);
}
