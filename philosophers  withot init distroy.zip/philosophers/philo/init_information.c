/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_information.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/08 12:31:23 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/29 22:36:45 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	init_forks(t_data *data)
{
	int	i;

	i = 0;
	data->forks = malloc(sizeof(pthread_mutex_t) * data->nb_ph);
	if (!data->forks)
		return ((void)write(2, "Error malloc forks\n", 20));
	while (i < data->nb_ph)
	{
		pthread_mutex_init(&data->forks[i], NULL);
		i++;
	}
}

void	init_inf_philos(t_data *data)
{
	int	i;

	i = 0;
	data->philo = malloc(sizeof(t_philo) * data->nb_ph);
	if (!data->philo)
		return ((void)write(2, "Error malloc philo\n", 20));
	pthread_mutex_init(&data->data_access, NULL);
	pthread_mutex_init(&data->write_acess, NULL);
	data->start_time = current_time_ms();
	i = 0;
	while (i < data->nb_ph)
	{
		data->philo[i].nbr_meal = 0;
		pthread_mutex_init(&data->philo[i].philo_access, NULL);
		data->philo[i].id = i + 1;
		data->philo[i].data = data;
		data->philo[i].last_meal = data->start_time;
		data->philo[i].left_fork = &data->forks[i];
		data->philo[i].right_fork = &data->forks[(i + 1) % data->nb_ph];
		i++;
	}
}

int	init_information(t_data *data, int nb_philo, char **av)
{
	data->nb_ph = nb_philo;
	data->time_to_die = ft_atoi(av[2]);
	data->time_to_eat = ft_atoi(av[3]);
	data->time_to_sleep = ft_atoi(av[4]);
	if (ft_atoi(av[5]))
		data->nb_time_eat = ft_atoi(av[5]);
	else
		data->nb_time_eat = -1;
	data->all_done = 0;
	init_forks(data);
	init_inf_philos(data);
	sim_philo(data);
	return (0);
}
