/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   destroy_all.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/26 09:20:49 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/29 22:27:49 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	destroy_all(t_data *data, int i)
{
	pthread_mutex_destroy(&data->data_access);
	pthread_mutex_destroy(&data->philo->philo_access);
	pthread_mutex_destroy(&data->write_acess);
	while (i--)
		pthread_mutex_destroy(&data->forks[i]);
	free(data->forks);
	free(data->philo);
}
