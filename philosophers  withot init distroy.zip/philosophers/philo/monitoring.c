/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitoring.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 20:54:45 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/29 22:28:37 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	check_meals(t_philo *philo)
{
	int		i;
	long	nbr_meal;

	i = 0;
	while (i < philo->data->nb_ph)
	{
		pthread_mutex_lock(&philo[i].philo_access);
		nbr_meal = philo[i].nbr_meal;
		pthread_mutex_unlock(&philo[i].philo_access);
		if (nbr_meal != philo->data->nb_time_eat)
			return (0);
		i++;
	}
	return (1);
}

int	display_die(t_philo *philo, int i)
{
	pthread_mutex_lock(&philo[i].philo_access);
	if ((current_time_ms() - philo[i].last_meal)
		>= philo[i].data->time_to_die)
	{
		pthread_mutex_lock(&philo->data->data_access);
		philo->data->all_done = 1;
		pthread_mutex_unlock(&philo->data->data_access);
		pthread_mutex_lock(&philo->data->write_acess);
		printf("%ld %ld died\n",
			(current_time_ms() - philo->data->start_time), philo->id);
		pthread_mutex_unlock(&philo->data->write_acess);
		pthread_mutex_unlock(&philo[i].philo_access);
		return (1);
	}
	pthread_mutex_unlock(&philo[i].philo_access);
	return (0);
}

void	*monitor(void *param)
{
	t_philo	*philo;
	int		i;

	philo = (t_philo *)param;
	i = 0;
	while (i < philo->data->nb_ph)
	{
		if (check_meals(philo) == 1)
		{
			pthread_mutex_lock(&philo->data->data_access);
			philo->data->all_done = 1;
			pthread_mutex_unlock(&philo->data->data_access);
			break ;
		}
		if (display_die(philo, i) == 1)
			break ;
		i = (i + 1) % philo[i].data->nb_ph;
	}
	return (NULL);
}

void	monitoring(t_data *data)
{
	if (pthread_create(&data->main_thread, NULL, monitor, data->philo))
	{
		destroy_all(data, data->nb_ph);
		write (2, "Error pthread_create\n", 22);
		return ;
	}
}
