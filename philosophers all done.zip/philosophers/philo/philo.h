/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/03 10:47:21 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/30 15:08:34 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <pthread.h>
# include <stdlib.h>
# include <unistd.h>
# include <stdio.h>
# include <sys/time.h>

typedef struct s_data	t_data;

typedef struct s_philo
{
	long			id;
	pthread_mutex_t	*left_fork;
	pthread_mutex_t	*right_fork;
	pthread_mutex_t	philo_access;
	pthread_t		th_philo;
	long			nbr_meal;
	long			last_meal;
	t_data			*data;
}	t_philo;

struct s_data
{
	pthread_mutex_t	*forks;
	pthread_mutex_t	data_access;
	pthread_mutex_t	write_acess;
	pthread_t		main_thread;
	int				nb_ph;
	long			time_to_eat;
	long			time_to_die;
	long			time_to_sleep;
	long			nb_time_eat;
	long			start_time;
	long			all_done;
	t_philo			*philo;
};

int		ft_atoi(const char *str);
int		parcing(int ac, char **av);
int		init_information(t_data *data, int nb_philo, char **av);
void	sim_philo(t_data *data);
long	ft_usleep(long time, t_philo *philo);
long	current_time_ms(void);
void	monitoring(t_data *data);
void	display_simulation(t_philo *philo, char *str);
void	destroy_all(t_data *data, int f, int p);

#endif