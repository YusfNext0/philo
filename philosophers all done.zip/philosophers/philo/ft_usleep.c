/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_usleep.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 00:08:59 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/29 21:43:06 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

long	ft_usleep(long time, t_philo *philo)
{
	long	start;

	start = current_time_ms();
	while (current_time_ms() - start < time)
	{
		pthread_mutex_lock(&philo->data->data_access);
		if (philo->data->all_done == 1)
		{
			pthread_mutex_unlock(&philo->data->data_access);
			break ;
		}
		pthread_mutex_unlock(&philo->data->data_access);
		usleep(500);
	}
	return (0);
}
