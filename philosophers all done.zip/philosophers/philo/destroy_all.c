/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   destroy_all.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/26 09:20:49 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/30 15:54:50 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	destroy_all(t_data *data, int f, int p)
{
	pthread_mutex_destroy(&data->data_access);
	while (p--)
		pthread_mutex_destroy(&data->philo[p].philo_access);
	pthread_mutex_destroy(&data->write_acess);
	while (f--)
		pthread_mutex_destroy(&data->forks[f]);
	free(data->forks);
	free(data->philo);
}
