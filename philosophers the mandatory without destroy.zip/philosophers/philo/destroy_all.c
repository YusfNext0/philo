/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   destroy_all.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/26 09:20:49 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/26 11:08:57 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void    destroy_all(t_data data)
{
    pthread_mutex_destroy(&counter.count_mutex);
    pthread_mutex_destroy(&counter.count_mutex);
    pthread_mutex_destroy(&counter.count_mutex);
}