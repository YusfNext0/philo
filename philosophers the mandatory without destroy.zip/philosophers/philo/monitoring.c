/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitoring.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ynachat <ynachat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 20:54:45 by ynachat           #+#    #+#             */
/*   Updated: 2024/08/26 16:19:29 by ynachat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int check_meals (t_philo *philo)
{
	int i;
	long nbr_meal;

	i = 0;
	while (i < philo->data->nb_ph)
	{
		pthread_mutex_lock(&philo[i].philo_access);
		nbr_meal = philo[i].nbr_meal;
		pthread_mutex_unlock(&philo[i].philo_access);
		if (nbr_meal != philo->data->nb_time_eat)
			return (0);
		i++;
	}
	return (1);
}

void *monitor(void *param)
{
	t_philo *philo;
	int	i;

	philo = (t_philo *)param;
	i = 0;
	while (i < philo->data->nb_ph)
	{
		if (check_meals(philo) == 1)
		{
			pthread_mutex_lock(&philo->data->data_access);
			philo->data->all_done = 1;
			pthread_mutex_unlock(&philo->data->data_access);
			return (NULL);
		}
		pthread_mutex_lock(&philo[i].philo_access);
		if ((current_time_ms() - philo[i].last_meal) >= philo[i].data->time_to_die && (philo[i].data->nb_time_eat == -1))
		{
			pthread_mutex_lock(&philo->data->data_access);
			philo->data->all_done = 1;
			pthread_mutex_unlock(&philo->data->data_access);
			printf("%ld %ld died\n",(current_time_ms() - philo[i].last_meal), philo[i].id);
			pthread_mutex_unlock(&philo[i].philo_access);
			return (NULL);
		}
		pthread_mutex_unlock(&philo[i].philo_access);
		i = (i + 1) % philo[i].data->nb_ph;
	}
	return (NULL);
}

void monitoring(t_data *data)
{
	if (pthread_create(&data->main_thread, NULL, monitor, data->philo))
	{
		printf("heeeeeeere is pthred_creat failed monitor <--\n");
		exit(1);
	}
}
